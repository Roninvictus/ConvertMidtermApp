package com.example.converter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import kotlin.text.toFloat as textToFloat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputKgValue = findViewById<EditText>(R.id.et_kg)
        val outputValue = findViewById<TextView>(R.id.tv_output)
        val radioGroup = findViewById<RadioGroup>(R.id.radio_group)
        val convertButton = findViewById<Button>(R.id.button)

        convertButton.setOnClickListener() {
            val kg = inputKgValue.text.toString().textToFloat()
            val conversion = when (radioGroup.checkedRadioButtonId) {
                R.id.radio_lbs_to_kg -> kg / 2.20462f
                R.id.radio_cm_to_inches -> kg / 2.54f
                R.id.radio_inches_to_cm -> kg * 2.54f
                R.id.radio_km_to_miles -> kg / 1.60934f
                else -> kg // no conversion selected
            }
            outputValue.text = String.format("%.2f", conversion)
        }
    }
}
